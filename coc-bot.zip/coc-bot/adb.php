<?php
require_once __DIR__ . '/config.php';

function adb(string $cmd): string {
    $serial = escapeshellarg(env_get('ADB_SERIAL', '127.0.0.1:5555'));
    return (string) shell_exec("adb -s $serial $cmd 2>&1");
}

function adb_connect(): string {
    return (string) shell_exec('adb connect ' . escapeshellarg(env_get('ADB_SERIAL', '127.0.0.1:5555')) . ' 2>&1');
}

function screenshot(string $path = SCREEN): bool {
    $serial = escapeshellarg(env_get('ADB_SERIAL', '127.0.0.1:5555'));
    shell_exec("adb -s $serial exec-out screencap -p > " . escapeshellarg($path));
    return file_exists($path) && filesize($path) > 1000;
}

function screen_size(): array {
    static $s = null;
    if ($s) return $s;
    if (preg_match('/(\d+)x(\d+)/', adb('shell wm size'), $m)) {
        $a = (int) $m[1]; $b = (int) $m[2];
        $s = [max($a, $b), min($a, $b)]; // اللعبة أفقية
    } else {
        $s = [1920, 1080];
    }
    return $s;
}

function human_pause(): void {
    [$min, $max] = SETTINGS['tap_delay_ms'];
    usleep(random_int($min, $max) * 1000);
}

function tap(int $x, int $y): void {
    $x += random_int(-4, 4);
    $y += random_int(-4, 4);
    adb("shell input tap $x $y");
    human_pause();
}

function tap_frac(float $fx, float $fy): void {
    [$w, $h] = screen_size();
    tap((int) ($w * $fx), (int) ($h * $fy));
}

function swipe(int $x1, int $y1, int $x2, int $y2, int $ms = 400): void {
    adb("shell input swipe $x1 $y1 $x2 $y2 $ms");
    human_pause();
}

function back_key(): void {
    adb('shell input keyevent 4');
    human_pause();
}

function type_text(string $text): void {
    adb('shell input text ' . escapeshellarg(str_replace(' ', '%s', $text)));
    human_pause();
}

function game_running(): bool {
    $pkg = env_get('GAME_PACKAGE', 'com.supercell.clashofclans');
    return trim(adb("shell pidof $pkg")) !== '';
}

function start_game(): void {
    $pkg = env_get('GAME_PACKAGE', 'com.supercell.clashofclans');
    adb("shell monkey -p $pkg -c android.intent.category.LAUNCHER 1");
    sleep(40);
}
