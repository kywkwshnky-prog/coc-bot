<?php
// تحميل ملف .env
function env_get(string $key, string $default = ''): string {
    static $env = null;
    if ($env === null) {
        $env = [];
        $file = __DIR__ . '/.env';
        if (file_exists($file)) {
            foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
                $line = trim($line);
                if ($line === '' || $line[0] === '#' || !str_contains($line, '=')) continue;
                [$k, $v] = explode('=', $line, 2);
                $env[trim($k)] = trim($v);
            }
        }
    }
    return $env[$key] ?? $default;
}

const BASE_DIR   = __DIR__;
const STOP_FILE  = __DIR__ . '/STOP';
const PID_FILE   = __DIR__ . '/worker.pid';
const SCREEN     = __DIR__ . '/screens/current.png';
const MODES_FILE = __DIR__ . '/modes.json';

// كل الأوضاع المتاحة (المفتاح => الاسم)
const ALL_MODES = [
    'collect'   => 'جمع الموارد',
    'walls'     => 'ترقية الجدران',
    'defense'   => 'ترقية الدفاعات',
    'buildings' => 'ترقية المباني',
    'build'     => 'بناء مباني جديدة',
    'attack'    => 'هجوم',
];

function get_modes(): array {
    if (file_exists(MODES_FILE)) {
        $m = json_decode((string) file_get_contents(MODES_FILE), true);
        if (is_array($m)) return array_values(array_intersect(array_keys(ALL_MODES), $m));
    }
    return ['collect', 'walls', 'defense']; // الافتراضي
}

function set_modes(array $modes): void {
    $modes = array_values(array_intersect(array_keys(ALL_MODES), $modes));
    file_put_contents(MODES_FILE, json_encode($modes));
}

const SETTINGS = [
    // بيت القرية مستثنى دائماً من الترقية
    'skip_upgrade' => ['town_hall'],
    'defense_priority' => ['cannon', 'archer_tower', 'mortar', 'air_defense', 'wizard_tower', 'xbow', 'inferno'],
    'building_priority' => ['laboratory', 'gold_storage', 'elixir_storage', 'barracks', 'army_camp', 'gold_mine', 'elixir_collector'],
    // تأخير عشوائي بالثواني بين الجولات
    'round_delay' => [240, 600],
    // تأخير عشوائي بين الضغطات بالمللي ثانية
    'tap_delay_ms' => [350, 1100],
    'match_threshold' => 0.85,
    // الهجوم: مواقع بنسبة من الشاشة (عدّلها حسب لعبتك)
    'troop_slots_x' => [0.12, 0.19, 0.26, 0.33],
    'troop_slots_y' => 0.92,
    'deploy_points' => [[0.28, 0.40], [0.33, 0.35], [0.38, 0.30], [0.43, 0.25], [0.48, 0.21]],
    'battle_timeout' => 200,
];
