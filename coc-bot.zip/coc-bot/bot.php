<?php
// بوت تيليجرام: php bot.php
require_once __DIR__ . '/notify.php';
require_once __DIR__ . '/adb.php';
require_once __DIR__ . '/vision.php';
require_once __DIR__ . '/tasks/login.php';

function worker_pid(): ?int {
    if (!file_exists(PID_FILE)) return null;
    $pid = (int) file_get_contents(PID_FILE);
    return ($pid > 0 && file_exists("/proc/$pid")) ? $pid : null;
}

function start_worker(): string {
    if (worker_pid()) return 'يعمل بالفعل';
    shell_exec('nohup ' . escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg(BASE_DIR . '/worker.php') . ' > ' . escapeshellarg(BASE_DIR . '/worker.log') . ' 2>&1 &');
    return 'جاري التشغيل...';
}

function stop_worker(): string {
    file_put_contents(STOP_FILE, '1');
    return 'تم إرسال طلب الإيقاف (يتوقف بعد المهمة الحالية)';
}

function menu_markup(): string {
    $active = get_modes();
    $rows = [];
    foreach (ALL_MODES as $key => $label) {
        $on = in_array($key, $active, true);
        $rows[] = [['text' => ($on ? '✅ ' : '⬜ ') . $label, 'callback_data' => "toggle:$key"]];
    }
    $rows[] = [
        ['text' => '▶️ بدء', 'callback_data' => 'run'],
        ['text' => '⏹ إيقاف', 'callback_data' => 'stop'],
    ];
    return json_encode(['inline_keyboard' => $rows], JSON_UNESCAPED_UNICODE);
}

function modes_text(): string {
    $names = array_map(fn($m) => ALL_MODES[$m], get_modes());
    return $names ? 'الأوضاع المفعّلة: ' . implode('، ', $names) : 'لا يوجد وضع مفعّل';
}

function help_text(): string {
    $keys = implode(' ', array_keys(ALL_MODES));
    return "الأوامر:\n"
        . "/menu قائمة أزرار لاختيار المهام\n"
        . "/run بدء  |  /stop إيقاف\n"
        . "/modes عرض الأوضاع\n"
        . "/only walls مهمة واحدة فقط\n"
        . "/set collect walls defense عدة مهام\n"
        . "/status الحالة  |  /screen لقطة الشاشة\n"
        . "/login email@example.com ثم /code 123456\n\n"
        . "أسماء الأوضاع: $keys";
}

$offset = 0;
echo "البوت يعمل...\n";
while (true) {
    $res = tg('getUpdates', ['offset' => $offset, 'timeout' => 50]);
    foreach ($res['result'] ?? [] as $u) {
        $offset = $u['update_id'] + 1;
        $allowed = env_get('ALLOWED_CHAT_ID');

        // ضغط زر من القائمة
        if (isset($u['callback_query'])) {
            $cb = $u['callback_query'];
            $chat = (string) $cb['message']['chat']['id'];
            if ($allowed === '' || $chat !== $allowed) continue;
            $data = $cb['data'] ?? '';
            $note = '';
            if (str_starts_with($data, 'toggle:')) {
                $key = substr($data, 7);
                if (isset(ALL_MODES[$key])) {
                    $modes = get_modes();
                    $modes = in_array($key, $modes, true) ? array_diff($modes, [$key]) : array_merge($modes, [$key]);
                    set_modes($modes);
                }
            } elseif ($data === 'run') { $note = start_worker(); }
            elseif ($data === 'stop') { $note = stop_worker(); }
            tg('answerCallbackQuery', ['callback_query_id' => $cb['id'], 'text' => $note]);
            tg('editMessageReplyMarkup', [
                'chat_id' => $chat, 'message_id' => $cb['message']['message_id'], 'reply_markup' => menu_markup(),
            ]);
            continue;
        }

        $msg = $u['message'] ?? null;
        if (!$msg || !isset($msg['text'])) continue;
        $chat = (string) $msg['chat']['id'];
        $text = trim($msg['text']);
        $reply = fn(string $t, array $extra = []) => tg('sendMessage', array_merge(['chat_id' => $chat, 'text' => $t], $extra));

        // أول مرة: لم يُضبط معرّف المحادثة بعد
        if ($allowed === '') {
            if (str_starts_with($text, '/start')) {
                $reply("معرّف محادثتك: $chat\nضعه في ملف .env مقابل ALLOWED_CHAT_ID ثم أعد تشغيل البوت.");
            }
            continue;
        }
        if ($chat !== $allowed) continue;

        $parts = preg_split('/\s+/', $text);
        $cmd = strtolower(explode('@', $parts[0])[0]);
        $args = array_slice($parts, 1);

        switch ($cmd) {
            case '/start':
                $reply(help_text());
                break;
            case '/menu':
                $reply('اختر المهام ثم اضغط بدء:', ['reply_markup' => menu_markup()]);
                break;
            case '/run':
                $reply(start_worker());
                break;
            case '/stop':
                $reply(stop_worker());
                break;
            case '/modes':
                $reply(modes_text());
                break;
            case '/only':
                if (isset($args[0], ALL_MODES[$args[0]])) { set_modes([$args[0]]); $reply(modes_text()); }
                else $reply('اكتب اسم وضع صحيح، مثال: /only walls');
                break;
            case '/set':
                $valid = array_values(array_filter($args, fn($a) => isset(ALL_MODES[$a])));
                if ($valid) { set_modes($valid); $reply(modes_text()); }
                else $reply('مثال: /set collect walls defense');
                break;
            case '/status':
                $s = file_exists(BASE_DIR . '/status.txt') ? file_get_contents(BASE_DIR . '/status.txt') : 'لا توجد جولات بعد';
                $reply((worker_pid() ? '🟢 يعمل' : '🔴 متوقف') . "\n" . modes_text() . "\n" . $s);
                break;
            case '/screen':
                if (screenshot()) tg('sendPhoto', ['chat_id' => $chat], SCREEN);
                else $reply('فشل التقاط الشاشة، تأكد من ADB');
                break;
            case '/login':
                if (worker_pid()) { $reply('أوقف العامل أولاً بـ /stop ثم أعد المحاولة'); break; }
                if (!isset($args[0]) || !str_contains($args[0], '@')) { $reply('مثال: /login email@example.com'); break; }
                $reply(login_start($args[0]));
                break;
            case '/code':
                if (worker_pid()) { $reply('أوقف العامل أولاً بـ /stop'); break; }
                if (!isset($args[0])) { $reply('مثال: /code 123456'); break; }
                $reply(login_code($args[0]));
                break;
            default:
                $reply(help_text());
        }
    }
}
