#!/usr/bin/env python3
"""مساعد التعرف على الصور: يبحث عن صورة قالب داخل لقطة الشاشة.
الاستخدام: python3 vision.py screen.png template.png [threshold]
الناتج JSON: {"found": true, "x": 540, "y": 320, "score": 0.93}
"""
import sys, json
import cv2

def main():
    screen_path, tpl_path = sys.argv[1], sys.argv[2]
    threshold = float(sys.argv[3]) if len(sys.argv) > 3 else 0.85
    screen = cv2.imread(screen_path)
    tpl = cv2.imread(tpl_path)
    if screen is None or tpl is None:
        print(json.dumps({"found": False, "error": "image_not_loaded"}))
        return
    res = cv2.matchTemplate(screen, tpl, cv2.TM_CCOEFF_NORMED)
    _, score, _, loc = cv2.minMaxLoc(res)
    h, w = tpl.shape[:2]
    print(json.dumps({
        "found": bool(score >= threshold),
        "x": int(loc[0] + w / 2),
        "y": int(loc[1] + h / 2),
        "score": round(float(score), 3),
    }))

main()
