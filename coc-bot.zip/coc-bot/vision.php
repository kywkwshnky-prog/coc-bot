<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/adb.php';

// يبحث عن قالب داخل الشاشة الحالية، يرجع [x, y] أو null
function find_template(string $templatePath, ?float $threshold = null): ?array {
    if (!file_exists($templatePath)) return null;
    $threshold ??= SETTINGS['match_threshold'];
    $py = env_get('PYTHON_BIN', 'python3');
    $cmd = sprintf('%s %s %s %s %s 2>&1', escapeshellarg($py), escapeshellarg(BASE_DIR . '/vision.py'),
        escapeshellarg(SCREEN), escapeshellarg($templatePath), $threshold);
    $out = json_decode((string) shell_exec($cmd), true);
    if (!$out || empty($out['found'])) return null;
    return [$out['x'], $out['y']];
}

// يلتقط الشاشة ثم يضغط على القالب (مسار نسبي داخل templates/)
function tap_template(string $rel): bool {
    screenshot();
    $pos = find_template(BASE_DIR . "/templates/$rel");
    if (!$pos) return false;
    tap($pos[0], $pos[1]);
    return true;
}
