<?php
// العامل: يشغّل الأوضاع المختارة بالتتابع، جولة بعد جولة
require_once __DIR__ . '/adb.php';
require_once __DIR__ . '/vision.php';
require_once __DIR__ . '/notify.php';
require_once __DIR__ . '/tasks/collect.php';
require_once __DIR__ . '/tasks/upgrade.php';
require_once __DIR__ . '/tasks/build.php';
require_once __DIR__ . '/tasks/attack.php';

file_put_contents(PID_FILE, getmypid());
@unlink(STOP_FILE);
adb_connect();
notify('✅ بدأ العامل: ' . implode('، ', array_map(fn($m) => ALL_MODES[$m], get_modes())));

$map = [
    'collect' => 'task_collect', 'walls' => 'task_walls', 'defense' => 'task_defense',
    'buildings' => 'task_buildings', 'build' => 'task_build', 'attack' => 'task_attack',
];

while (!file_exists(STOP_FILE)) {
    try {
        if (!game_running()) { notify('⚠️ اللعبة مغلقة، أعيد تشغيلها'); start_game(); }
        $modes = get_modes(); // تتحدث كل جولة
        $parts = [];
        foreach (array_keys(ALL_MODES) as $m) {
            if (!in_array($m, $modes, true) || file_exists(STOP_FILE)) continue;
            $n = $map[$m]();
            $parts[] = ALL_MODES[$m] . ": $n";
        }
        file_put_contents(BASE_DIR . '/status.txt', date('Y-m-d H:i:s') . ' | ' . implode(' | ', $parts));
    } catch (Throwable $e) {
        notify('❌ خطأ: ' . $e->getMessage());
    }
    [$min, $max] = SETTINGS['round_delay'];
    $wait = random_int($min, $max);
    for ($i = 0; $i < $wait && !file_exists(STOP_FILE); $i++) sleep(1);
}
@unlink(PID_FILE);
notify('⏹ توقف العامل');
