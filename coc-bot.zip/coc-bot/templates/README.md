# القوالب (Templates)
صور PNG مقصوصة من لقطة الشاشة (/screen) بنفس دقة الأندرويد على السيرفر:

- `collect/`  : أيقونات جمع الموارد
- `upgrade/`  : cannon.png, archer_tower.png, wall.png, laboratory.png ... + upgrade_button.png + confirm.png
- `build/`    : أيقونات عناصر المتجر المراد بناؤها
- `attack/`   : attack_button, find_match, surrender, surrender_confirm, return_home
- `login/`    : settings, supercell_id, email_field, continue, code_field, confirm
- `ui/`       : shop.png, confirm_place.png

أي قالب ناقص تتخطاه المهمة بصمت. ابدأ بقوالب الجمع، ثم الترقية.
