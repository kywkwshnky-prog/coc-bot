<?php
// جمع الموارد: يضغط على كل قالب موجود في templates/collect/
function task_collect(): int {
    $count = 0;
    screenshot();
    foreach (glob(BASE_DIR . '/templates/collect/*.png') as $tpl) {
        for ($i = 0; $i < 6; $i++) {
            $pos = find_template($tpl);
            if (!$pos) break;
            tap($pos[0], $pos[1]);
            $count++;
            screenshot();
        }
    }
    return $count;
}
