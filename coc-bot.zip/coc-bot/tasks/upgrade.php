<?php
// ترقية قائمة مباني. بيت القرية مستثنى دائماً.
// القوالب: templates/upgrade/<اسم>.png + upgrade_button.png + confirm.png
function upgrade_list(array $names): int {
    $done = 0;
    screenshot();
    foreach ($names as $name) {
        if ($name === 'town_hall' || in_array($name, SETTINGS['skip_upgrade'], true)) continue;
        $pos = find_template(BASE_DIR . "/templates/upgrade/$name.png");
        if (!$pos) continue;
        tap($pos[0], $pos[1]);
        screenshot();
        $btn = find_template(BASE_DIR . '/templates/upgrade/upgrade_button.png');
        if (!$btn) { back_key(); screenshot(); continue; }
        tap($btn[0], $btn[1]);
        screenshot();
        $ok = find_template(BASE_DIR . '/templates/upgrade/confirm.png');
        if ($ok) { tap($ok[0], $ok[1]); $done++; }
        else { back_key(); }
        screenshot();
    }
    return $done;
}

function task_walls(): int     { return upgrade_list(['wall']); }
function task_defense(): int   { return upgrade_list(SETTINGS['defense_priority']); }
function task_buildings(): int { return upgrade_list(SETTINGS['building_priority']); }
