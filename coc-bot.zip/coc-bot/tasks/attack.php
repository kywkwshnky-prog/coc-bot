<?php
// هجوم بسيط: يبحث عن خصم، ينزّل القوات على نقاط محددة، ينتظر النهاية.
// القوالب داخل attack/: attack_button, find_match, surrender, surrender_confirm, return_home
// الفوز غير مضمون: يعتمد على جيشك ومواقع النزول في config.php
function task_attack(): int {
    if (!tap_template('attack/attack_button.png')) return 0;
    sleep(2);
    if (!tap_template('attack/find_match.png')) { back_key(); return 0; }
    sleep(random_int(8, 12)); // تحميل القرية

    foreach (SETTINGS['troop_slots_x'] as $fx) {
        tap_frac($fx, SETTINGS['troop_slots_y']);
        foreach (SETTINGS['deploy_points'] as [$px, $py]) {
            tap_frac($px, $py);
        }
    }

    $deadline = time() + SETTINGS['battle_timeout'];
    while (time() < $deadline) {
        if (tap_template('attack/return_home.png')) return 1;
        sleep(5);
    }
    // انتهى الوقت: استسلام ثم رجوع
    tap_template('attack/surrender.png');
    tap_template('attack/surrender_confirm.png');
    sleep(3);
    tap_template('attack/return_home.png');
    return 1;
}
