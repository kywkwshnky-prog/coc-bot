<?php
// بناء مباني جديدة من المتجر.
// القوالب: ui/shop.png و ui/confirm_place.png، وأيقونات العناصر داخل build/
function task_build(): int {
    $done = 0;
    foreach (glob(BASE_DIR . '/templates/build/*.png') as $item) {
        if (!tap_template('ui/shop.png')) continue;
        sleep(2);
        $found = null;
        for ($i = 0; $i < 5 && !$found; $i++) {
            screenshot();
            $found = find_template($item);
            if (!$found) swipe(1400, 600, 600, 600); // تمرير المتجر
        }
        if (!$found) { back_key(); continue; }
        tap($found[0], $found[1]);
        sleep(2);
        tap_frac(0.5, 0.5); // موضع البناء (وسط الشاشة)
        if (tap_template('ui/confirm_place.png')) $done++;
        else back_key();
    }
    return $done;
}
