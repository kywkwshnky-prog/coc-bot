<?php
// تسجيل الدخول عبر Supercell ID (كود يصل للإيميل، لا حاجة لكلمة سر)
// القوالب داخل login/: settings, supercell_id, email_field, continue, code_field, confirm
function login_start(string $email): string {
    foreach (['settings', 'supercell_id', 'email_field'] as $step) {
        if (!tap_template("login/$step.png")) return "لم أجد الزر: $step";
        sleep(2);
    }
    type_text($email);
    if (!tap_template('login/continue.png')) return 'لم أجد زر المتابعة';
    return 'تم إدخال الإيميل. افتح بريدك وأرسل الكود هكذا: /code 123456';
}

function login_code(string $code): string {
    if (!tap_template('login/code_field.png')) return 'لم أجد خانة الكود';
    type_text($code);
    tap_template('login/confirm.png');
    return 'تم إدخال الكود. تحقق بـ /screen';
}
