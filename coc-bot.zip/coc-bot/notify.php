<?php
require_once __DIR__ . '/config.php';

function tg(string $method, array $params = [], ?string $file = null) {
    $url = 'https://api.telegram.org/bot' . env_get('BOT_TOKEN') . '/' . $method;
    $ch = curl_init($url);
    if ($file) $params['photo'] = new CURLFile($file);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POSTFIELDS => $params, CURLOPT_TIMEOUT => 70]);
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode((string) $res, true);
}

function notify(string $text): void {
    if (env_get('ALLOWED_CHAT_ID') === '') return;
    tg('sendMessage', ['chat_id' => env_get('ALLOWED_CHAT_ID'), 'text' => $text]);
}
